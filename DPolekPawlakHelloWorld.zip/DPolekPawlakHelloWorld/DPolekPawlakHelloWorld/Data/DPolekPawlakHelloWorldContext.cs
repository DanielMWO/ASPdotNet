﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace DPolekPawlakHelloWorld.Models
{
    public class DPolekPawlakHelloWorldContext : DbContext
    {
        public DPolekPawlakHelloWorldContext (DbContextOptions<DPolekPawlakHelloWorldContext> options)
            : base(options)
        {
        }

        public DbSet<DPolekPawlakHelloWorld.Models.Animal> Animal { get; set; }
    }
}
