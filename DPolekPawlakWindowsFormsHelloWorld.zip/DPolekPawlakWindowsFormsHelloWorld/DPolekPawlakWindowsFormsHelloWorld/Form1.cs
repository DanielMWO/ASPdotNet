﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DPolekPawlakWindowsFormsHelloWorld
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        List<Osoba> osoby = new List<Osoba>();

        private void button1_Click(object sender, EventArgs e)
        {
            int listLenghth = comboBox1.Items.Count;
            if (listLenghth > 0)
            {
                comboBox1.Items.RemoveAt(listLenghth - 1);
                osoby.RemoveAt(osoby.Count - 1);

            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            String name = textBox1.Text;
            String surname = textBox2.Text;

            //comboBox1.Items.Add(name + " " + surname);

           Osoba os = new Osoba { Name = name, Surname = surname };
           osoby.Add(os);
           String item = osoby[osoby.Count - 1].Name + " " + osoby[osoby.Count - 1].Surname;
           comboBox1.Items.Add(item);


        }

        private void showData_Click(object sender, EventArgs e)
        {
            DataForm form = new DataForm();
            form.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Persons personsForm = new Persons();
            personsForm.ShowDialog();
        }
    }

       }


