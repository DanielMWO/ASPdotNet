﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DPolekPawlakWindowsFormsHelloWorld
{
    public partial class Persons : Form
    {
        public Persons()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Persons_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'danielPolekDB1DataSet.Osoby' table. You can move, or remove it, as needed.
            this.osobyTableAdapter.Fill(this.danielPolekDB1DataSet.Osoby);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.osobyTableAdapter.Update(this.danielPolekDB1DataSet.Osoby);
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
           DataGridViewSelectedRowCollection rows = dataGridView1.SelectedRows;
           foreach (DataGridViewRow row in rows) {
                 dataGridView1.Rows.Remove(row);
           }
           this.osobyTableAdapter.Update(this.danielPolekDB1DataSet.Osoby);
           
        }
    }
}
